from flask import Flask
from flask_pymongo import PyMongo
from .config import Config

app = Flask(__name__)

# Set SECRET_KEY for CSRF protection
app.config["SECRET_KEY"] = "your_secret_key_here"  # Replace with a strong key

# Configure MongoDB
app.config["MONGO_URI"] = "mongodb+srv://ai_portal3:ai_portal3@cluster-aiportal.n80no.mongodb.net/"

mongo = PyMongo(app)

from app import routes  # Ensure this is at the bottom to avoid circular imports
